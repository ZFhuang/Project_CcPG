<?xml version="1.0" encoding="UTF-8"?>
<tileset name="地图素材" tilewidth="32" tileheight="32" tilecount="225" columns="15">
 <image source="地图素材.png" width="480" height="480"/>
</tileset>
