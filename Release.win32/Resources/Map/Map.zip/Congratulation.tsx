<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Congratulation" tilewidth="32" tileheight="32" tilecount="54" columns="18">
 <image source="Congratulation.png" width="580" height="99"/>
</tileset>
